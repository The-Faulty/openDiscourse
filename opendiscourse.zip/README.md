# openDiscourse

Created with CodeSandbox
Currently a basic text messaging platform loosely based off Discord
Ctrl+i, Ctrl+b, and Ctrl+u work for text decorations and Shift+Enter works for line breaks

The app uses React for UI purposes, and Google's firebase for user authentication and the realtime database.

TODO:
-Finish Servers

Change Log:

v0.1.1:
-Fixed react router 404 with \_redirects
-Implemented DOMPurify sanitization of user input
-Messages only load after siging in (wont be necessary after introduction of homepage)
-Parser implemented

v0.1.0:
-Initial release
-Server functionality partially complete
